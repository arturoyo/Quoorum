--
-- PostgreSQL database dump
--

\restrict LjIFp9Od8ceCs80nyWMD0rVsiuD9Q1x0PTaOa45eln93bUOQJXgbt33gwL9WBVY

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: admin_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.admin_role AS ENUM (
    'super_admin',
    'admin',
    'moderator',
    'support'
);


ALTER TYPE public.admin_role OWNER TO postgres;

--
-- Name: consultation_trigger; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.consultation_trigger AS ENUM (
    'price_negotiation',
    'competitor_mention',
    'objection_complex',
    'high_value_client',
    'escalation_risk',
    'contract_terms',
    'strategic_decision',
    'churn_signal'
);


ALTER TYPE public.consultation_trigger OWNER TO postgres;

--
-- Name: consultation_urgency; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.consultation_urgency AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public.consultation_urgency OWNER TO postgres;

--
-- Name: deal_stage; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.deal_stage AS ENUM (
    'lead',
    'qualified',
    'proposal',
    'negotiation',
    'commitment',
    'closed_won',
    'closed_lost'
);


ALTER TYPE public.deal_stage OWNER TO postgres;

--
-- Name: debate_deal_context; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.debate_deal_context AS ENUM (
    'pricing_strategy',
    'negotiation_tactics',
    'objection_handling',
    'proposal_review',
    'competitor_analysis',
    'closing_strategy',
    'risk_assessment',
    'value_proposition',
    'general'
);


ALTER TYPE public.debate_deal_context OWNER TO postgres;

--
-- Name: debate_influence; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.debate_influence AS ENUM (
    'decisive',
    'significant',
    'moderate',
    'minimal',
    'none',
    'unknown'
);


ALTER TYPE public.debate_influence OWNER TO postgres;

--
-- Name: debate_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.debate_mode AS ENUM (
    'static',
    'dynamic'
);


ALTER TYPE public.debate_mode OWNER TO postgres;

--
-- Name: debate_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.debate_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'failed',
    'cancelled',
    'draft'
);


ALTER TYPE public.debate_status OWNER TO postgres;

--
-- Name: debate_visibility; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.debate_visibility AS ENUM (
    'private',
    'team',
    'public'
);


ALTER TYPE public.debate_visibility OWNER TO postgres;

--
-- Name: feedback_sentiment; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.feedback_sentiment AS ENUM (
    'helpful',
    'neutral',
    'unhelpful'
);


ALTER TYPE public.feedback_sentiment OWNER TO postgres;

--
-- Name: log_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.log_level AS ENUM (
    'debug',
    'info',
    'warn',
    'error',
    'fatal'
);


ALTER TYPE public.log_level OWNER TO postgres;

--
-- Name: log_source; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.log_source AS ENUM (
    'client',
    'server',
    'worker',
    'cron'
);


ALTER TYPE public.log_source OWNER TO postgres;

--
-- Name: plan_tier; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.plan_tier AS ENUM (
    'free',
    'starter',
    'pro',
    'business',
    'enterprise'
);


ALTER TYPE public.plan_tier OWNER TO postgres;

--
-- Name: quoorum_notification_channel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quoorum_notification_channel AS ENUM (
    'in_app',
    'email',
    'push',
    'whatsapp'
);


ALTER TYPE public.quoorum_notification_channel OWNER TO postgres;

--
-- Name: quoorum_notification_priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quoorum_notification_priority AS ENUM (
    'low',
    'normal',
    'high',
    'urgent'
);


ALTER TYPE public.quoorum_notification_priority OWNER TO postgres;

--
-- Name: quoorum_notification_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quoorum_notification_type AS ENUM (
    'debate_completed',
    'debate_failed',
    'new_comment',
    'comment_reply',
    'debate_shared',
    'consensus_reached',
    'expert_recommendation',
    'weekly_digest',
    'debate_reminder',
    'team_action'
);


ALTER TYPE public.quoorum_notification_type OWNER TO postgres;

--
-- Name: quoorum_report_format; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quoorum_report_format AS ENUM (
    'pdf',
    'html',
    'markdown'
);


ALTER TYPE public.quoorum_report_format OWNER TO postgres;

--
-- Name: quoorum_report_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quoorum_report_status AS ENUM (
    'pending',
    'generating',
    'completed',
    'failed'
);


ALTER TYPE public.quoorum_report_status OWNER TO postgres;

--
-- Name: quoorum_report_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quoorum_report_type AS ENUM (
    'single_debate',
    'weekly_summary',
    'monthly_summary',
    'deal_analysis',
    'expert_performance',
    'custom'
);


ALTER TYPE public.quoorum_report_type OWNER TO postgres;

--
-- Name: response_approach; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.response_approach AS ENUM (
    'empathetic',
    'assertive',
    'consultative',
    'direct'
);


ALTER TYPE public.response_approach OWNER TO postgres;

--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.subscription_status AS ENUM (
    'active',
    'canceled',
    'past_due',
    'trialing',
    'paused',
    'unpaid'
);


ALTER TYPE public.subscription_status OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_roles OWNER TO postgres;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    role_id uuid,
    role public.admin_role DEFAULT 'support'::public.admin_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_users OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(10) NOT NULL,
    permissions jsonb DEFAULT '{"read": true, "write": false, "delete": false}'::jsonb,
    last_used_at timestamp with time zone,
    usage_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action character varying(100) NOT NULL,
    user_id uuid,
    deliberation_id uuid,
    entity_type character varying(100),
    entity_id uuid,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(50),
    company character varying(255),
    notes text,
    metadata jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: consensus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.consensus (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deliberation_id uuid NOT NULL,
    round_id uuid,
    achieved boolean DEFAULT false NOT NULL,
    score real NOT NULL,
    summary text NOT NULL,
    recommendation text,
    dissenting jsonb DEFAULT '[]'::jsonb,
    quality_assessment text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.consensus OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id uuid,
    channel character varying(50) DEFAULT 'web'::character varying NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    title character varying(255),
    summary text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: deals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    client_id uuid,
    owner_id uuid,
    stage public.deal_stage DEFAULT 'lead'::public.deal_stage NOT NULL,
    value real,
    currency character varying(10) DEFAULT 'USD'::character varying,
    probability real,
    expected_close_date timestamp with time zone,
    description text,
    notes text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.deals OWNER TO postgres;

--
-- Name: deliberations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliberations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(500) NOT NULL,
    description text NOT NULL,
    topic text NOT NULL,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    created_by_id uuid NOT NULL,
    objectives jsonb DEFAULT '[]'::jsonb,
    constraints jsonb DEFAULT '[]'::jsonb,
    max_rounds integer DEFAULT 5 NOT NULL,
    current_round integer DEFAULT 0 NOT NULL,
    consensus_threshold integer DEFAULT 70 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.deliberations OWNER TO postgres;

--
-- Name: experts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    expertise character varying(500) NOT NULL,
    description text,
    system_prompt text NOT NULL,
    ai_config jsonb NOT NULL,
    category character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.experts OWNER TO postgres;

--
-- Name: opinions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opinions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    expert_id uuid NOT NULL,
    content text NOT NULL,
    reasoning text NOT NULL,
    confidence real NOT NULL,
    quality_score real,
    "position" integer,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.opinions OWNER TO postgres;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    tier public.plan_tier DEFAULT 'free'::public.plan_tier NOT NULL,
    description text,
    monthly_price_usd integer DEFAULT 0 NOT NULL,
    yearly_price_usd integer DEFAULT 0 NOT NULL,
    stripe_price_id_monthly character varying(255),
    stripe_price_id_yearly character varying(255),
    stripe_product_id character varying(255),
    debates_per_month integer DEFAULT 5 NOT NULL,
    max_experts integer DEFAULT 4 NOT NULL,
    max_rounds_per_debate integer DEFAULT 3 NOT NULL,
    max_team_members integer DEFAULT 1 NOT NULL,
    features jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plans OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email character varying(255),
    name character varying(255),
    full_name character varying(255),
    avatar_url text,
    role character varying(100) DEFAULT 'user'::character varying,
    settings jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: quoorum_api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(20) NOT NULL,
    scopes jsonb DEFAULT '["debates:read", "debates:write"]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    request_count integer DEFAULT 0 NOT NULL,
    last_ip character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_api_keys OWNER TO postgres;

--
-- Name: quoorum_consultations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_consultations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid,
    conversation_id uuid,
    original_message text NOT NULL,
    triggers jsonb NOT NULL,
    urgency public.consultation_urgency DEFAULT 'low'::public.consultation_urgency NOT NULL,
    complexity_confidence real,
    strategy text,
    response_approach public.response_approach,
    talking_points jsonb,
    avoid_saying jsonb,
    risks_to_address jsonb,
    opportunities_to_leverage jsonb,
    negotiation_guidance jsonb,
    recommend_human_escalation boolean DEFAULT false,
    escalation_reason text,
    advice_confidence real,
    was_advice_used boolean DEFAULT true,
    processing_time_ms integer,
    user_rating integer,
    user_feedback text,
    client_context jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_consultations OWNER TO postgres;

--
-- Name: TABLE quoorum_consultations; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.quoorum_consultations IS 'Stores automatic Forum consultations during Wallie response generation';


--
-- Name: quoorum_context_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_context_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    source_type character varying(20) NOT NULL,
    source_data jsonb,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_context_sources OWNER TO postgres;

--
-- Name: quoorum_custom_experts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_custom_experts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    expertise jsonb NOT NULL,
    philosophy text NOT NULL,
    approach text NOT NULL,
    style text NOT NULL,
    training_docs jsonb,
    is_active boolean DEFAULT true NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_custom_experts OWNER TO postgres;

--
-- Name: TABLE quoorum_custom_experts; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.quoorum_custom_experts IS 'User-created custom experts for debates';


--
-- Name: quoorum_deal_links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_deal_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    debate_id uuid NOT NULL,
    deal_id uuid NOT NULL,
    context public.debate_deal_context DEFAULT 'general'::public.debate_deal_context NOT NULL,
    notes text,
    influence public.debate_influence DEFAULT 'unknown'::public.debate_influence,
    influence_notes text,
    recommendation_followed boolean,
    outcome_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_deal_links OWNER TO postgres;

--
-- Name: quoorum_deal_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_deal_recommendations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    deal_id uuid NOT NULL,
    recommendation text NOT NULL,
    confidence text,
    based_on_debates jsonb,
    suggested_actions jsonb,
    risk_factors jsonb,
    is_active boolean DEFAULT true NOT NULL,
    dismissed_at timestamp with time zone,
    dismiss_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.quoorum_deal_recommendations OWNER TO postgres;

--
-- Name: quoorum_debate_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_debate_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    debate_id uuid NOT NULL,
    user_id uuid NOT NULL,
    content text NOT NULL,
    parent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_debate_comments OWNER TO postgres;

--
-- Name: TABLE quoorum_debate_comments; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.quoorum_debate_comments IS 'Team collaboration comments on debates with mentions support';


--
-- Name: quoorum_debate_likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_debate_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    debate_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_debate_likes OWNER TO postgres;

--
-- Name: quoorum_debate_reactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_debate_reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    debate_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reaction character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_debate_reactions OWNER TO postgres;

--
-- Name: TABLE quoorum_debate_reactions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.quoorum_debate_reactions IS 'User reactions to debates (like, bookmark, etc)';


--
-- Name: quoorum_debate_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_debate_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    industry character varying(50),
    category character varying(50),
    question_template text NOT NULL,
    suggested_experts jsonb,
    default_context jsonb,
    usage_count integer DEFAULT 0 NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_debate_templates OWNER TO postgres;

--
-- Name: quoorum_debates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_debates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    question text NOT NULL,
    mode public.debate_mode DEFAULT 'dynamic'::public.debate_mode NOT NULL,
    status public.debate_status DEFAULT 'pending'::public.debate_status NOT NULL,
    visibility public.debate_visibility DEFAULT 'private'::public.debate_visibility NOT NULL,
    context jsonb,
    consensus_score real,
    total_rounds integer,
    total_cost_usd real,
    final_ranking jsonb,
    rounds jsonb,
    experts jsonb,
    quality_metrics jsonb,
    interventions jsonb,
    share_token character varying(64),
    shared_with jsonb,
    view_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    comment_count integer DEFAULT 0 NOT NULL,
    metadata jsonb,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.quoorum_debates OWNER TO postgres;

--
-- Name: TABLE quoorum_debates; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.quoorum_debates IS 'Stores debates from the dynamic expert system with full history and analytics';


--
-- Name: quoorum_expert_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_expert_feedback (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    debate_id uuid NOT NULL,
    expert_id text NOT NULL,
    rating integer NOT NULL,
    sentiment public.feedback_sentiment DEFAULT 'neutral'::public.feedback_sentiment NOT NULL,
    comment text,
    insightfulness integer,
    relevance integer,
    clarity integer,
    actionability integer,
    was_followed boolean,
    was_successful boolean,
    outcome_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_expert_feedback OWNER TO postgres;

--
-- Name: quoorum_expert_performance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_expert_performance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    expert_id character varying(100) NOT NULL,
    total_debates integer DEFAULT 0 NOT NULL,
    total_wins integer DEFAULT 0 NOT NULL,
    avg_quality_score real,
    avg_consensus_score real,
    chemistry_scores jsonb,
    topic_performance jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_expert_performance OWNER TO postgres;

--
-- Name: TABLE quoorum_expert_performance; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.quoorum_expert_performance IS 'Performance tracking and learning system for experts';


--
-- Name: quoorum_expert_ratings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_expert_ratings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    expert_id text NOT NULL,
    total_ratings integer DEFAULT 0 NOT NULL,
    avg_rating integer,
    avg_insightfulness integer,
    avg_relevance integer,
    avg_clarity integer,
    avg_actionability integer,
    helpful_count integer DEFAULT 0 NOT NULL,
    neutral_count integer DEFAULT 0 NOT NULL,
    unhelpful_count integer DEFAULT 0 NOT NULL,
    followed_count integer DEFAULT 0 NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_expert_ratings OWNER TO postgres;

--
-- Name: quoorum_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    round integer NOT NULL,
    agent_key character varying(50) NOT NULL,
    agent_name character varying(100),
    content text NOT NULL,
    is_compressed boolean DEFAULT true,
    tokens_used integer,
    cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_messages OWNER TO postgres;

--
-- Name: quoorum_notification_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    debate_completed jsonb DEFAULT '{"enabled": true, "channels": ["in_app", "email"]}'::jsonb,
    new_comment jsonb DEFAULT '{"enabled": true, "channels": ["in_app"]}'::jsonb,
    debate_shared jsonb DEFAULT '{"enabled": true, "channels": ["in_app", "email"]}'::jsonb,
    weekly_digest jsonb DEFAULT '{"hour": 9, "enabled": true, "dayOfWeek": 1}'::jsonb,
    email_enabled boolean DEFAULT true NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL,
    quiet_hours_start text,
    quiet_hours_end text,
    timezone text DEFAULT 'Europe/Madrid'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_notification_preferences OWNER TO postgres;

--
-- Name: quoorum_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.quoorum_notification_type NOT NULL,
    priority public.quoorum_notification_priority DEFAULT 'normal'::public.quoorum_notification_priority NOT NULL,
    debate_id uuid,
    title text NOT NULL,
    message text NOT NULL,
    action_url text,
    action_label text,
    metadata jsonb,
    channels jsonb,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    is_archived boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.quoorum_notifications OWNER TO postgres;

--
-- Name: quoorum_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.quoorum_report_type NOT NULL,
    title text NOT NULL,
    description text,
    format public.quoorum_report_format DEFAULT 'pdf'::public.quoorum_report_format NOT NULL,
    status public.quoorum_report_status DEFAULT 'pending'::public.quoorum_report_status NOT NULL,
    error_message text,
    file_url text,
    file_size integer,
    file_name text,
    parameters jsonb,
    summary jsonb,
    share_token text,
    expires_at timestamp with time zone,
    generated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_reports OWNER TO postgres;

--
-- Name: quoorum_scheduled_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_scheduled_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    type public.quoorum_report_type NOT NULL,
    format public.quoorum_report_format DEFAULT 'pdf'::public.quoorum_report_format NOT NULL,
    schedule jsonb NOT NULL,
    delivery_method jsonb NOT NULL,
    parameters jsonb,
    is_active boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    last_report_id uuid,
    next_run_at timestamp with time zone,
    run_count integer DEFAULT 0 NOT NULL,
    fail_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_scheduled_reports OWNER TO postgres;

--
-- Name: quoorum_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    question text NOT NULL,
    manual_context text,
    use_internet boolean DEFAULT false,
    use_repo boolean DEFAULT false,
    repo_path text,
    status character varying(20) DEFAULT 'running'::character varying NOT NULL,
    total_rounds integer DEFAULT 0,
    consensus_score numeric(4,2),
    final_ranking jsonb,
    total_cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.quoorum_sessions OWNER TO postgres;

--
-- Name: quoorum_translations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_translations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    translation text NOT NULL,
    tokens_used integer,
    cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_translations OWNER TO postgres;

--
-- Name: quoorum_webhook_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_webhook_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    webhook_id uuid NOT NULL,
    event character varying(50) NOT NULL,
    payload jsonb,
    success boolean NOT NULL,
    status_code integer,
    response_body text,
    error_message text,
    delivery_duration_ms integer,
    attempt_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_webhook_logs OWNER TO postgres;

--
-- Name: quoorum_webhooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quoorum_webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(100) DEFAULT 'Webhook'::character varying NOT NULL,
    url text NOT NULL,
    secret character varying(64),
    events jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_triggered_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    last_error_message text,
    success_count integer DEFAULT 0 NOT NULL,
    fail_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quoorum_webhooks OWNER TO postgres;

--
-- Name: rounds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rounds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deliberation_id uuid NOT NULL,
    round_number integer NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    summary text,
    moderator_notes text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rounds OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status public.subscription_status DEFAULT 'active'::public.subscription_status NOT NULL,
    stripe_customer_id character varying(255),
    stripe_subscription_id character varying(255),
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    trial_start timestamp with time zone,
    trial_end timestamp with time zone,
    canceled_at timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    level public.log_level NOT NULL,
    source public.log_source NOT NULL,
    message text NOT NULL,
    metadata jsonb,
    error_name character varying(255),
    error_message text,
    error_stack text,
    duration_ms jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_logs OWNER TO postgres;

--
-- Name: usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    debates_used integer DEFAULT 0 NOT NULL,
    tokens_used integer DEFAULT 0 NOT NULL,
    api_calls_used integer DEFAULT 0 NOT NULL,
    total_cost_usd integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.usage OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    avatar_url text,
    role character varying(50) DEFAULT 'member'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.votes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    expert_id uuid NOT NULL,
    opinion_id uuid NOT NULL,
    weight real DEFAULT 1 NOT NULL,
    score integer NOT NULL,
    justification text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.votes OWNER TO postgres;

--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_roles (id, name, slug, description, permissions, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_users (id, user_id, profile_id, role_id, role, is_active, last_login_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, user_id, name, key_hash, key_prefix, permissions, last_used_at, usage_count, is_active, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, action, user_id, deliberation_id, entity_type, entity_id, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, name, email, phone, company, notes, metadata, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: consensus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.consensus (id, deliberation_id, round_id, achieved, score, summary, recommendation, dissenting, quality_assessment, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, client_id, channel, status, title, summary, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deals (id, user_id, name, client_id, owner_id, stage, value, currency, probability, expected_close_date, description, notes, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deliberations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliberations (id, title, description, topic, status, created_by_id, objectives, constraints, max_rounds, current_round, consensus_threshold, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: experts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.experts (id, name, expertise, description, system_prompt, ai_config, category, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: opinions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opinions (id, round_id, expert_id, content, reasoning, confidence, quality_score, "position", metadata, created_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plans (id, name, tier, description, monthly_price_usd, yearly_price_usd, stripe_price_id_monthly, stripe_price_id_yearly, stripe_product_id, debates_per_month, max_experts, max_rounds_per_debate, max_team_members, features, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (id, user_id, email, name, full_name, avatar_url, role, settings, is_active, created_at, updated_at) FROM stdin;
f198d53b-9524-45b9-87cf-a810a857a616	b88193ab-1c38-49a0-a86b-cf12a96f66a9	usuario@quoorum.com	Usuario Quoorum	\N	\N	user	\N	t	2026-01-15 14:14:07.968502+00	2026-01-15 14:14:07.968502+00
\.


--
-- Data for Name: quoorum_api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_api_keys (id, user_id, name, key_hash, key_prefix, scopes, is_active, last_used_at, expires_at, revoked_at, request_count, last_ip, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_consultations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_consultations (id, user_id, client_id, conversation_id, original_message, triggers, urgency, complexity_confidence, strategy, response_approach, talking_points, avoid_saying, risks_to_address, opportunities_to_leverage, negotiation_guidance, recommend_human_escalation, escalation_reason, advice_confidence, was_advice_used, processing_time_ms, user_rating, user_feedback, client_context, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_context_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_context_sources (id, session_id, source_type, source_data, content, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_custom_experts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_custom_experts (id, user_id, name, expertise, philosophy, approach, style, training_docs, is_active, usage_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_deal_links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_deal_links (id, user_id, debate_id, deal_id, context, notes, influence, influence_notes, recommendation_followed, outcome_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_deal_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_deal_recommendations (id, user_id, deal_id, recommendation, confidence, based_on_debates, suggested_actions, risk_factors, is_active, dismissed_at, dismiss_reason, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: quoorum_debate_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_debate_comments (id, debate_id, user_id, content, parent_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_debate_likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_debate_likes (id, debate_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_debate_reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_debate_reactions (id, debate_id, user_id, reaction, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_debate_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_debate_templates (id, name, description, industry, category, question_template, suggested_experts, default_context, usage_count, is_public, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_debates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_debates (id, user_id, question, mode, status, visibility, context, consensus_score, total_rounds, total_cost_usd, final_ranking, rounds, experts, quality_metrics, interventions, share_token, shared_with, view_count, like_count, comment_count, metadata, started_at, completed_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: quoorum_expert_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_expert_feedback (id, user_id, debate_id, expert_id, rating, sentiment, comment, insightfulness, relevance, clarity, actionability, was_followed, was_successful, outcome_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_expert_performance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_expert_performance (id, expert_id, total_debates, total_wins, avg_quality_score, avg_consensus_score, chemistry_scores, topic_performance, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_expert_ratings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_expert_ratings (id, expert_id, total_ratings, avg_rating, avg_insightfulness, avg_relevance, avg_clarity, avg_actionability, helpful_count, neutral_count, unhelpful_count, followed_count, success_count, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_messages (id, session_id, round, agent_key, agent_name, content, is_compressed, tokens_used, cost_usd, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_notification_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_notification_preferences (id, user_id, debate_completed, new_comment, debate_shared, weekly_digest, email_enabled, push_enabled, quiet_hours_start, quiet_hours_end, timezone, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_notifications (id, user_id, type, priority, debate_id, title, message, action_url, action_label, metadata, channels, is_read, read_at, is_archived, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: quoorum_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_reports (id, user_id, type, title, description, format, status, error_message, file_url, file_size, file_name, parameters, summary, share_token, expires_at, generated_at, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_scheduled_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_scheduled_reports (id, user_id, name, type, format, schedule, delivery_method, parameters, is_active, last_run_at, last_report_id, next_run_at, run_count, fail_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quoorum_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_sessions (id, user_id, question, manual_context, use_internet, use_repo, repo_path, status, total_rounds, consensus_score, final_ranking, total_cost_usd, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: quoorum_translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_translations (id, message_id, translation, tokens_used, cost_usd, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_webhook_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_webhook_logs (id, webhook_id, event, payload, success, status_code, response_body, error_message, delivery_duration_ms, attempt_number, created_at) FROM stdin;
\.


--
-- Data for Name: quoorum_webhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quoorum_webhooks (id, user_id, name, url, secret, events, is_active, last_triggered_at, last_success_at, last_failure_at, last_error_message, success_count, fail_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rounds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rounds (id, deliberation_id, round_number, status, summary, moderator_notes, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, user_id, plan_id, status, stripe_customer_id, stripe_subscription_id, current_period_start, current_period_end, trial_start, trial_end, canceled_at, cancel_at_period_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_logs (id, user_id, level, source, message, metadata, error_name, error_message, error_stack, duration_ms, created_at) FROM stdin;
\.


--
-- Data for Name: usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usage (id, user_id, period_start, period_end, debates_used, tokens_used, api_calls_used, total_cost_usd, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, avatar_url, role, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.votes (id, round_id, expert_id, opinion_id, weight, score, justification, created_at) FROM stdin;
\.


--
-- Name: admin_roles admin_roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_name_unique UNIQUE (name);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_roles admin_roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_slug_unique UNIQUE (slug);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: consensus consensus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consensus
    ADD CONSTRAINT consensus_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: deals deals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_pkey PRIMARY KEY (id);


--
-- Name: deliberations deliberations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliberations
    ADD CONSTRAINT deliberations_pkey PRIMARY KEY (id);


--
-- Name: experts experts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT experts_pkey PRIMARY KEY (id);


--
-- Name: opinions opinions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opinions
    ADD CONSTRAINT opinions_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: quoorum_api_keys quoorum_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_api_keys
    ADD CONSTRAINT quoorum_api_keys_pkey PRIMARY KEY (id);


--
-- Name: quoorum_consultations quoorum_consultations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_consultations
    ADD CONSTRAINT quoorum_consultations_pkey PRIMARY KEY (id);


--
-- Name: quoorum_context_sources quoorum_context_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_context_sources
    ADD CONSTRAINT quoorum_context_sources_pkey PRIMARY KEY (id);


--
-- Name: quoorum_custom_experts quoorum_custom_experts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_custom_experts
    ADD CONSTRAINT quoorum_custom_experts_pkey PRIMARY KEY (id);


--
-- Name: quoorum_deal_links quoorum_deal_links_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_links
    ADD CONSTRAINT quoorum_deal_links_pkey PRIMARY KEY (id);


--
-- Name: quoorum_deal_recommendations quoorum_deal_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_recommendations
    ADD CONSTRAINT quoorum_deal_recommendations_pkey PRIMARY KEY (id);


--
-- Name: quoorum_debate_comments quoorum_debate_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_comments
    ADD CONSTRAINT quoorum_debate_comments_pkey PRIMARY KEY (id);


--
-- Name: quoorum_debate_likes quoorum_debate_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_likes
    ADD CONSTRAINT quoorum_debate_likes_pkey PRIMARY KEY (id);


--
-- Name: quoorum_debate_reactions quoorum_debate_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_reactions
    ADD CONSTRAINT quoorum_debate_reactions_pkey PRIMARY KEY (id);


--
-- Name: quoorum_debate_reactions quoorum_debate_reactions_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_reactions
    ADD CONSTRAINT quoorum_debate_reactions_unique UNIQUE (debate_id, user_id, reaction);


--
-- Name: quoorum_debate_templates quoorum_debate_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_templates
    ADD CONSTRAINT quoorum_debate_templates_pkey PRIMARY KEY (id);


--
-- Name: quoorum_debates quoorum_debates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debates
    ADD CONSTRAINT quoorum_debates_pkey PRIMARY KEY (id);


--
-- Name: quoorum_expert_feedback quoorum_expert_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_expert_feedback
    ADD CONSTRAINT quoorum_expert_feedback_pkey PRIMARY KEY (id);


--
-- Name: quoorum_expert_performance quoorum_expert_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_expert_performance
    ADD CONSTRAINT quoorum_expert_performance_pkey PRIMARY KEY (id);


--
-- Name: quoorum_expert_ratings quoorum_expert_ratings_expert_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_expert_ratings
    ADD CONSTRAINT quoorum_expert_ratings_expert_id_unique UNIQUE (expert_id);


--
-- Name: quoorum_expert_ratings quoorum_expert_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_expert_ratings
    ADD CONSTRAINT quoorum_expert_ratings_pkey PRIMARY KEY (id);


--
-- Name: quoorum_messages quoorum_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_messages
    ADD CONSTRAINT quoorum_messages_pkey PRIMARY KEY (id);


--
-- Name: quoorum_notification_preferences quoorum_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_notification_preferences
    ADD CONSTRAINT quoorum_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: quoorum_notification_preferences quoorum_notification_preferences_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_notification_preferences
    ADD CONSTRAINT quoorum_notification_preferences_user_id_unique UNIQUE (user_id);


--
-- Name: quoorum_notifications quoorum_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_notifications
    ADD CONSTRAINT quoorum_notifications_pkey PRIMARY KEY (id);


--
-- Name: quoorum_reports quoorum_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_reports
    ADD CONSTRAINT quoorum_reports_pkey PRIMARY KEY (id);


--
-- Name: quoorum_scheduled_reports quoorum_scheduled_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_scheduled_reports
    ADD CONSTRAINT quoorum_scheduled_reports_pkey PRIMARY KEY (id);


--
-- Name: quoorum_sessions quoorum_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_sessions
    ADD CONSTRAINT quoorum_sessions_pkey PRIMARY KEY (id);


--
-- Name: quoorum_translations quoorum_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_translations
    ADD CONSTRAINT quoorum_translations_pkey PRIMARY KEY (id);


--
-- Name: quoorum_webhook_logs quoorum_webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_webhook_logs
    ADD CONSTRAINT quoorum_webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: quoorum_webhooks quoorum_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_webhooks
    ADD CONSTRAINT quoorum_webhooks_pkey PRIMARY KEY (id);


--
-- Name: rounds rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: usage usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usage
    ADD CONSTRAINT usage_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_pkey PRIMARY KEY (id);


--
-- Name: idx_quoorum_consultations_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_consultations_client ON public.quoorum_consultations USING btree (client_id);


--
-- Name: idx_quoorum_consultations_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_consultations_conversation ON public.quoorum_consultations USING btree (conversation_id);


--
-- Name: idx_quoorum_consultations_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_consultations_created ON public.quoorum_consultations USING btree (created_at);


--
-- Name: idx_quoorum_consultations_urgency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_consultations_urgency ON public.quoorum_consultations USING btree (urgency);


--
-- Name: idx_quoorum_consultations_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_consultations_user ON public.quoorum_consultations USING btree (user_id);


--
-- Name: idx_quoorum_context_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_context_session ON public.quoorum_context_sources USING btree (session_id);


--
-- Name: idx_quoorum_deal_links_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_links_context ON public.quoorum_deal_links USING btree (context);


--
-- Name: idx_quoorum_deal_links_deal; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_links_deal ON public.quoorum_deal_links USING btree (deal_id);


--
-- Name: idx_quoorum_deal_links_debate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_links_debate ON public.quoorum_deal_links USING btree (debate_id);


--
-- Name: idx_quoorum_deal_links_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_links_user ON public.quoorum_deal_links USING btree (user_id);


--
-- Name: idx_quoorum_deal_recs_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_recs_active ON public.quoorum_deal_recommendations USING btree (deal_id, is_active);


--
-- Name: idx_quoorum_deal_recs_deal; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_recs_deal ON public.quoorum_deal_recommendations USING btree (deal_id);


--
-- Name: idx_quoorum_deal_recs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_deal_recs_user ON public.quoorum_deal_recommendations USING btree (user_id);


--
-- Name: idx_quoorum_expert_feedback_debate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_expert_feedback_debate ON public.quoorum_expert_feedback USING btree (debate_id);


--
-- Name: idx_quoorum_expert_feedback_expert; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_expert_feedback_expert ON public.quoorum_expert_feedback USING btree (expert_id);


--
-- Name: idx_quoorum_expert_feedback_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_expert_feedback_rating ON public.quoorum_expert_feedback USING btree (rating);


--
-- Name: idx_quoorum_expert_feedback_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_expert_feedback_user ON public.quoorum_expert_feedback USING btree (user_id);


--
-- Name: idx_quoorum_expert_ratings_avg; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_expert_ratings_avg ON public.quoorum_expert_ratings USING btree (avg_rating);


--
-- Name: idx_quoorum_messages_round; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_messages_round ON public.quoorum_messages USING btree (session_id, round);


--
-- Name: idx_quoorum_messages_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_messages_session ON public.quoorum_messages USING btree (session_id);


--
-- Name: idx_quoorum_notifications_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_notifications_created ON public.quoorum_notifications USING btree (created_at);


--
-- Name: idx_quoorum_notifications_debate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_notifications_debate ON public.quoorum_notifications USING btree (debate_id);


--
-- Name: idx_quoorum_notifications_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_notifications_type ON public.quoorum_notifications USING btree (type);


--
-- Name: idx_quoorum_notifications_unread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_notifications_unread ON public.quoorum_notifications USING btree (user_id, is_read);


--
-- Name: idx_quoorum_notifications_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_notifications_user ON public.quoorum_notifications USING btree (user_id);


--
-- Name: idx_quoorum_reports_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_reports_created ON public.quoorum_reports USING btree (created_at);


--
-- Name: idx_quoorum_reports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_reports_status ON public.quoorum_reports USING btree (status);


--
-- Name: idx_quoorum_reports_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_reports_type ON public.quoorum_reports USING btree (type);


--
-- Name: idx_quoorum_reports_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_reports_user ON public.quoorum_reports USING btree (user_id);


--
-- Name: idx_quoorum_scheduled_reports_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_scheduled_reports_active ON public.quoorum_scheduled_reports USING btree (is_active);


--
-- Name: idx_quoorum_scheduled_reports_next; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_scheduled_reports_next ON public.quoorum_scheduled_reports USING btree (next_run_at);


--
-- Name: idx_quoorum_scheduled_reports_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_scheduled_reports_user ON public.quoorum_scheduled_reports USING btree (user_id);


--
-- Name: idx_quoorum_sessions_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_sessions_created ON public.quoorum_sessions USING btree (created_at);


--
-- Name: idx_quoorum_sessions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_sessions_status ON public.quoorum_sessions USING btree (status);


--
-- Name: idx_quoorum_sessions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_sessions_user ON public.quoorum_sessions USING btree (user_id);


--
-- Name: idx_quoorum_translations_message; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quoorum_translations_message ON public.quoorum_translations USING btree (message_id);


--
-- Name: quoorum_custom_experts_is_active_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_custom_experts_is_active_idx ON public.quoorum_custom_experts USING btree (is_active);


--
-- Name: quoorum_custom_experts_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_custom_experts_user_id_idx ON public.quoorum_custom_experts USING btree (user_id);


--
-- Name: quoorum_debate_comments_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debate_comments_created_at_idx ON public.quoorum_debate_comments USING btree (created_at);


--
-- Name: quoorum_debate_comments_debate_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debate_comments_debate_id_idx ON public.quoorum_debate_comments USING btree (debate_id);


--
-- Name: quoorum_debate_comments_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debate_comments_user_id_idx ON public.quoorum_debate_comments USING btree (user_id);


--
-- Name: quoorum_debate_reactions_debate_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debate_reactions_debate_id_idx ON public.quoorum_debate_reactions USING btree (debate_id);


--
-- Name: quoorum_debate_reactions_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debate_reactions_user_id_idx ON public.quoorum_debate_reactions USING btree (user_id);


--
-- Name: quoorum_debates_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debates_created_at_idx ON public.quoorum_debates USING btree (created_at);


--
-- Name: quoorum_debates_share_token_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debates_share_token_idx ON public.quoorum_debates USING btree (share_token);


--
-- Name: quoorum_debates_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debates_status_idx ON public.quoorum_debates USING btree (status);


--
-- Name: quoorum_debates_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_debates_user_id_idx ON public.quoorum_debates USING btree (user_id);


--
-- Name: quoorum_expert_performance_expert_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX quoorum_expert_performance_expert_id_idx ON public.quoorum_expert_performance USING btree (expert_id);


--
-- Name: system_logs_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX system_logs_created_at_idx ON public.system_logs USING btree (created_at);


--
-- Name: system_logs_level_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX system_logs_level_idx ON public.system_logs USING btree (level);


--
-- Name: system_logs_source_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX system_logs_source_idx ON public.system_logs USING btree (source);


--
-- Name: system_logs_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX system_logs_user_id_idx ON public.system_logs USING btree (user_id);


--
-- Name: system_logs_user_level_created_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX system_logs_user_level_created_idx ON public.system_logs USING btree (user_id, level, created_at);


--
-- Name: admin_users admin_users_profile_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_profile_id_profiles_id_fk FOREIGN KEY (profile_id) REFERENCES public.profiles(id);


--
-- Name: admin_users admin_users_role_id_admin_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_role_id_admin_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id);


--
-- Name: admin_users admin_users_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id);


--
-- Name: api_keys api_keys_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_deliberation_id_deliberations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_deliberation_id_deliberations_id_fk FOREIGN KEY (deliberation_id) REFERENCES public.deliberations(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: consensus consensus_deliberation_id_deliberations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consensus
    ADD CONSTRAINT consensus_deliberation_id_deliberations_id_fk FOREIGN KEY (deliberation_id) REFERENCES public.deliberations(id) ON DELETE CASCADE;


--
-- Name: consensus consensus_round_id_rounds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.consensus
    ADD CONSTRAINT consensus_round_id_rounds_id_fk FOREIGN KEY (round_id) REFERENCES public.rounds(id);


--
-- Name: conversations conversations_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: deals deals_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: deals deals_owner_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_owner_id_profiles_id_fk FOREIGN KEY (owner_id) REFERENCES public.profiles(id);


--
-- Name: deals deals_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id);


--
-- Name: deliberations deliberations_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliberations
    ADD CONSTRAINT deliberations_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: opinions opinions_expert_id_experts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opinions
    ADD CONSTRAINT opinions_expert_id_experts_id_fk FOREIGN KEY (expert_id) REFERENCES public.experts(id);


--
-- Name: opinions opinions_round_id_rounds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opinions
    ADD CONSTRAINT opinions_round_id_rounds_id_fk FOREIGN KEY (round_id) REFERENCES public.rounds(id) ON DELETE CASCADE;


--
-- Name: quoorum_api_keys quoorum_api_keys_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_api_keys
    ADD CONSTRAINT quoorum_api_keys_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_consultations quoorum_consultations_client_id_clients_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_consultations
    ADD CONSTRAINT quoorum_consultations_client_id_clients_id_fk FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: quoorum_consultations quoorum_consultations_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_consultations
    ADD CONSTRAINT quoorum_consultations_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: quoorum_consultations quoorum_consultations_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_consultations
    ADD CONSTRAINT quoorum_consultations_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_context_sources quoorum_context_sources_session_id_quoorum_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_context_sources
    ADD CONSTRAINT quoorum_context_sources_session_id_quoorum_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.quoorum_sessions(id) ON DELETE CASCADE;


--
-- Name: quoorum_custom_experts quoorum_custom_experts_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_custom_experts
    ADD CONSTRAINT quoorum_custom_experts_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_deal_links quoorum_deal_links_deal_id_deals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_links
    ADD CONSTRAINT quoorum_deal_links_deal_id_deals_id_fk FOREIGN KEY (deal_id) REFERENCES public.deals(id) ON DELETE CASCADE;


--
-- Name: quoorum_deal_links quoorum_deal_links_debate_id_quoorum_debates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_links
    ADD CONSTRAINT quoorum_deal_links_debate_id_quoorum_debates_id_fk FOREIGN KEY (debate_id) REFERENCES public.quoorum_debates(id) ON DELETE CASCADE;


--
-- Name: quoorum_deal_links quoorum_deal_links_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_links
    ADD CONSTRAINT quoorum_deal_links_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_deal_recommendations quoorum_deal_recommendations_deal_id_deals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_recommendations
    ADD CONSTRAINT quoorum_deal_recommendations_deal_id_deals_id_fk FOREIGN KEY (deal_id) REFERENCES public.deals(id) ON DELETE CASCADE;


--
-- Name: quoorum_deal_recommendations quoorum_deal_recommendations_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_deal_recommendations
    ADD CONSTRAINT quoorum_deal_recommendations_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_comments quoorum_debate_comments_debate_id_quoorum_debates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_comments
    ADD CONSTRAINT quoorum_debate_comments_debate_id_quoorum_debates_id_fk FOREIGN KEY (debate_id) REFERENCES public.quoorum_debates(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_comments quoorum_debate_comments_parent_id_quoorum_debate_comments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_comments
    ADD CONSTRAINT quoorum_debate_comments_parent_id_quoorum_debate_comments_id_fk FOREIGN KEY (parent_id) REFERENCES public.quoorum_debate_comments(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_comments quoorum_debate_comments_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_comments
    ADD CONSTRAINT quoorum_debate_comments_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_likes quoorum_debate_likes_debate_id_quoorum_debates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_likes
    ADD CONSTRAINT quoorum_debate_likes_debate_id_quoorum_debates_id_fk FOREIGN KEY (debate_id) REFERENCES public.quoorum_debates(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_likes quoorum_debate_likes_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_likes
    ADD CONSTRAINT quoorum_debate_likes_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_reactions quoorum_debate_reactions_debate_id_quoorum_debates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_reactions
    ADD CONSTRAINT quoorum_debate_reactions_debate_id_quoorum_debates_id_fk FOREIGN KEY (debate_id) REFERENCES public.quoorum_debates(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_reactions quoorum_debate_reactions_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_reactions
    ADD CONSTRAINT quoorum_debate_reactions_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_templates quoorum_debate_templates_created_by_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debate_templates
    ADD CONSTRAINT quoorum_debate_templates_created_by_profiles_id_fk FOREIGN KEY (created_by) REFERENCES public.profiles(id) ON DELETE SET NULL;


--
-- Name: quoorum_debates quoorum_debates_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_debates
    ADD CONSTRAINT quoorum_debates_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_expert_feedback quoorum_expert_feedback_debate_id_quoorum_debates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_expert_feedback
    ADD CONSTRAINT quoorum_expert_feedback_debate_id_quoorum_debates_id_fk FOREIGN KEY (debate_id) REFERENCES public.quoorum_debates(id) ON DELETE CASCADE;


--
-- Name: quoorum_expert_feedback quoorum_expert_feedback_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_expert_feedback
    ADD CONSTRAINT quoorum_expert_feedback_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_messages quoorum_messages_session_id_quoorum_sessions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_messages
    ADD CONSTRAINT quoorum_messages_session_id_quoorum_sessions_id_fk FOREIGN KEY (session_id) REFERENCES public.quoorum_sessions(id) ON DELETE CASCADE;


--
-- Name: quoorum_notification_preferences quoorum_notification_preferences_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_notification_preferences
    ADD CONSTRAINT quoorum_notification_preferences_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_notifications quoorum_notifications_debate_id_quoorum_debates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_notifications
    ADD CONSTRAINT quoorum_notifications_debate_id_quoorum_debates_id_fk FOREIGN KEY (debate_id) REFERENCES public.quoorum_debates(id) ON DELETE CASCADE;


--
-- Name: quoorum_notifications quoorum_notifications_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_notifications
    ADD CONSTRAINT quoorum_notifications_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_reports quoorum_reports_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_reports
    ADD CONSTRAINT quoorum_reports_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_scheduled_reports quoorum_scheduled_reports_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_scheduled_reports
    ADD CONSTRAINT quoorum_scheduled_reports_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: quoorum_translations quoorum_translations_message_id_quoorum_messages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_translations
    ADD CONSTRAINT quoorum_translations_message_id_quoorum_messages_id_fk FOREIGN KEY (message_id) REFERENCES public.quoorum_messages(id) ON DELETE CASCADE;


--
-- Name: quoorum_webhook_logs quoorum_webhook_logs_webhook_id_quoorum_webhooks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_webhook_logs
    ADD CONSTRAINT quoorum_webhook_logs_webhook_id_quoorum_webhooks_id_fk FOREIGN KEY (webhook_id) REFERENCES public.quoorum_webhooks(id) ON DELETE CASCADE;


--
-- Name: quoorum_webhooks quoorum_webhooks_user_id_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quoorum_webhooks
    ADD CONSTRAINT quoorum_webhooks_user_id_profiles_id_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: rounds rounds_deliberation_id_deliberations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rounds
    ADD CONSTRAINT rounds_deliberation_id_deliberations_id_fk FOREIGN KEY (deliberation_id) REFERENCES public.deliberations(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_plan_id_plans_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_plans_id_fk FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: subscriptions subscriptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_logs system_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: usage usage_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usage
    ADD CONSTRAINT usage_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: votes votes_expert_id_experts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_expert_id_experts_id_fk FOREIGN KEY (expert_id) REFERENCES public.experts(id);


--
-- Name: votes votes_opinion_id_opinions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_opinion_id_opinions_id_fk FOREIGN KEY (opinion_id) REFERENCES public.opinions(id);


--
-- Name: votes votes_round_id_rounds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_round_id_rounds_id_fk FOREIGN KEY (round_id) REFERENCES public.rounds(id) ON DELETE CASCADE;


--
-- Name: quoorum_debate_templates Debate templates viewable by all; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Debate templates viewable by all" ON public.quoorum_debate_templates FOR SELECT USING (true);


--
-- Name: plans Plans are viewable by everyone; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Plans are viewable by everyone" ON public.plans FOR SELECT USING (true);


--
-- Name: quoorum_translations Translations viewable by all; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Translations viewable by all" ON public.quoorum_translations FOR SELECT USING (true);


--
-- Name: admin_roles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.admin_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: admin_users; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

--
-- Name: api_keys; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: consensus; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.consensus ENABLE ROW LEVEL SECURITY;

--
-- Name: conversations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

--
-- Name: deals; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;

--
-- Name: deliberations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.deliberations ENABLE ROW LEVEL SECURITY;

--
-- Name: experts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.experts ENABLE ROW LEVEL SECURITY;

--
-- Name: opinions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.opinions ENABLE ROW LEVEL SECURITY;

--
-- Name: plans; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_api_keys; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_consultations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_consultations ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_context_sources; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_context_sources ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_custom_experts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_custom_experts ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_deal_links; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_deal_links ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_deal_recommendations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_deal_recommendations ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_debate_comments; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_debate_comments ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_debate_likes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_debate_likes ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_debate_templates; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_debate_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_debates; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_debates ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_expert_feedback; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_expert_feedback ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_expert_performance; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_expert_performance ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_expert_ratings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_expert_ratings ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_messages; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_notification_preferences; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_notification_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_notifications; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_reports; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_scheduled_reports; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_scheduled_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_sessions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_translations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_translations ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_webhook_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_webhook_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: quoorum_webhooks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quoorum_webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: rounds; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rounds ENABLE ROW LEVEL SECURITY;

--
-- Name: subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: usage; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.usage ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: votes; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict LjIFp9Od8ceCs80nyWMD0rVsiuD9Q1x0PTaOa45eln93bUOQJXgbt33gwL9WBVY

